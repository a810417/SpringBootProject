package com.isapn.springbootdemo.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GoodPhotoDao extends JpaRepository<GoodPhoto, Integer> {

}
