package com.isapn.springbootdemo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isapn.springbootdemo.model.GoodPhoto;
import com.isapn.springbootdemo.model.GoodPhotoDao;

@Service
@Transactional
public class GoodPhotoService {
	
	@Autowired
	private GoodPhotoDao gDao;

	
	public GoodPhoto insertGoodPhoto(GoodPhoto gp) {
		return gDao.save(gp);
	}
	
	public List<GoodPhoto> listGoodPhoto() {
		return gDao.findAll();
	}
	
	public GoodPhoto getPhotoById(Integer id) {
		Optional<GoodPhoto> op = gDao.findById(id);
		
		if(op.isPresent()) {
			return op.get();
		}
		
		return null;
	}
	
	
}
